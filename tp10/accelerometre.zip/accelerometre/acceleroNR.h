/* -------------------- */
/* --- acceleroNR.c --- */
/* -------------------- */

/*
 * Copyright (c) 2015-2016 Lionel Lacassagne, all rights reserved,  LIP6, UPMC
 */

#ifndef _ACCELERO_NR_H_
#define _ACCELERO_NR_H_

void arduino_init1(void);
void arduino_loop1(void);

void arduino_init2(void);
void arduino_loop2(void);

#endif // _ACCELERO_NR_H_